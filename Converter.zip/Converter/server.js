const express = require("express");
const multer = require("multer");
const { exec } = require("child_process");
const fs = require("fs");
const path = require("path");

const app = express();
const port = 3000;

const upload = multer({ dest: "uploads/" });
app.use(express.static("public")); // Make sure your index.html is in /public

app.post("/convert/doc-to-pdf", upload.single("file"), (req, res) => {
  const inputFilePath = req.file.path;
  const outputDir = path.join(__dirname, "converted");

  const originalName = req.file.originalname;
  const baseName = path.parse(originalName).name;
  const outputFilePath = path.join(outputDir, `${baseName}.pdf`);

  const command = `"C:\\Program Files\\LibreOffice\\program\\soffice.exe" --headless --convert-to pdf --outdir "${outputDir}" "${inputFilePath}"`;

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error("LibreOffice error:", stderr);
      return res.status(500).send("Conversion failed.");
    }

    // Wait for file then download
    const checkInterval = setInterval(() => {
      if (fs.existsSync(outputFilePath)) {
        clearInterval(checkInterval);

        res.download(outputFilePath, `${baseName}.pdf`, (err) => {
          if (err) {
            console.error("Download error:", err.message);
            return res.status(500).send("Download failed.");
          }

          // Cleanup
          fs.unlinkSync(inputFilePath);
          fs.unlinkSync(outputFilePath);
        });
      }
    }, 200);
  });
});

app.listen(port, () => {
  console.log(`✅ Server running at http://localhost:${port}`);
});
